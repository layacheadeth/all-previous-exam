


class Sales {
    // each object contains details of one sale
    private String itemId; // id of the item
    private double value; // the price of one item
    private int quantity;
    // the number of the items sold

    public Sales(String itemid,double value,int quantity){
        this.itemId=itemid;
        this.value=value;
        this.quantity=quantity;
    }

    // constructor missing
    public double getValue() {return value;}
    public int getQuantity() {return quantity;}
}


class SalesPerson {
    // each object contains details of one salesperson
    private String id;
    private Sales [] salesHistory=null;
    private int count = 0; // number of sales made
    //constructor for a new salesperson
    public SalesPerson(String id){
        this.id=id;
    }

    public SalesPerson(String id, Sales[] s, int c){
        this.id=id;
        this.salesHistory=s;
        this.count=c;

    }
    public int getCount(){return count;}
    public String getId() {return id;}

    public Sales getSalesHistory(Sales s){

        count=count+1;
        return salesHistory[count];

    }

    public void setSalesHistory(Sales s){

        salesHistory[count] =  s;
        count = count +1;
    }

//    public Sales largestSale(){
//
//
//    }
}

//b the accessor method is important here because the field has been set to private
// Hence, inorder to let other class to safely access to the field, accessor play an important role here.




public class company {
    public static  void main(String [] args){
        SalesPerson[] salesPeople = new SalesPerson[6];

         Sales [] sale=new Sales[6];
        salesPeople[0] = new SalesPerson("100");
        salesPeople[1] = new SalesPerson("101");
        salesPeople[2] = new SalesPerson("102");
        salesPeople[0].setSalesHistory(new Sales("A100",300.00,10));
        salesPeople[0].setSalesHistory(new Sales("A200",1000.00,2));
        salesPeople[1].setSalesHistory(new Sales("A300",2550.40,10));
        System.out.println(salesPeople[2].getId());
        System.out.println(salesPeople[0].getCount());
        System.out.println(salesPeople[1].getSalesHistory(new Sales("A300",200,0)).getValue());
        
    }

}
