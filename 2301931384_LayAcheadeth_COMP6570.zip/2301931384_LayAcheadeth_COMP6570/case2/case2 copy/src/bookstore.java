class book{
    private
    String book_title;
    double price;
    String year_of_publish;
    String author_name;
    public
    book(){}
    book(String author_name,String book_title,double price, String year_of_publish){
        this.author_name=author_name;
        this.book_title=book_title;
        this.price=price;
        this.year_of_publish=year_of_publish;
    }

    public String getBook_title() {
        return book_title;
    }

    public void setBook_title(String book_title) {
        this.book_title = book_title;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getYear_of_publish() {
        return year_of_publish;
    }

    public void setYear_of_publish(String year_of_publish) {
        this.year_of_publish = year_of_publish;
    }

    public String getAuthor_name() {
        return author_name;
    }

    public void setAuthor_name(String author_name) {
        this.author_name = author_name;
    }

    @Override
    public String toString() {
        return "book{" +
                "author_name='" + author_name + '\'' +
                "book_title='" + book_title + '\'' +
                ", price=" + price +
                ", year_of_publish='" + year_of_publish + '\'' +
                '}';
    }
}

public class bookstore{

    public  static void main(String [] args){
        book Superheroes_are_Real=new book("Raymond Bahana"," Superheroes are Real",15.50,"1719");
        book  Falling_in_Love_with_Polymorphism=new book("Nunung Nurul"," Falling in Love with Polymorphism",12.80,"1902");
        book Bleh_Bleh_Bleh_Bleh=new book("Jude Martinez","Bleh Bleh Bleh Bleh",9.5,"1996");
        System.out.println(Superheroes_are_Real.toString());
        System.out.println(Falling_in_Love_with_Polymorphism.toString());
        System.out.println(Bleh_Bleh_Bleh_Bleh.toString());


    }
    // The new Book("Ida Bagus","The Young Doctor",900,1974)
    // this phrase mean a new book object has been created from its blueprint or class(book) following by the authorname:Ida Bagus, book_title:The young doctor, Price: 900, year of publish:1974

}