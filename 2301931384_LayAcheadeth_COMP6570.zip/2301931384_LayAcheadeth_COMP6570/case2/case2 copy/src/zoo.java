class animal{
    String name;
    int weight;
    public
    animal(){}
    animal(String name, int weight){
        this.name=name;
        this.weight=weight;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    @Override
    public String toString() {
        return "animal{" +
                "name='" + name + '\'' +
                ", weight=" + weight +
                '}';
    }
}
class lion extends animal{
    private
    int meat_eaten;
    public
    lion(){}
    lion(String name,int weight,int meat_eaten){
       super.name=name;
       super.weight=weight;
        this.meat_eaten=meat_eaten;
    }

    public int getMeat_eaten() {
        return meat_eaten;
    }

    public void setMeat_eaten(int meat_eaten) {
        this.meat_eaten = meat_eaten;
    }

    @Override
    public String toString() {
        return "lion{" +
                "name= "+getName()+
                ", weight=" + weight +
                ", meat_eaten=" + meat_eaten +
                '}';
    }
}

class snake extends animal{
    private
    int length;
    public
    snake(){};
    snake(String name, int weight,int length){
        super.name=name;
        super.weight=weight;
        this.length=length;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    @Override
    public String toString() {
        return "snake{" +
                "name= "+getName()+
                ", weight=" + weight +
                ", length=" + length +
                '}';
    }
}

class monkey extends animal{
    private
    String fav_food;
    public
    monkey(){};
    monkey(String name, int weight,String fav_food){
        super.name=name;
        super.weight=weight;
        this.fav_food=fav_food;
    }

    public String getFav_food() {
        return fav_food;
    }

    public void setFav_food(String fav_food) {
        this.fav_food = fav_food;
    }

    @Override
    public String toString() {
        return "monkey{" +
                "name= "+getName()+
                "weight=" + weight +
                ", fav_food='" + fav_food + '\'' +
                '}';
    }
}




public class zoo {

    public static void main(String [] args){
        lion leo=new lion("leo",300,5);
        snake ana=new snake("ana",50,5);
        monkey George=new monkey("George",120,"Kiwi");
        System.out.println(leo.toString());
        System.out.println(ana.toString());
        System.out.println(George.toString());

    }
}
